  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBi-bpTrfljY78j4lvN62vLlWzqXMTciMM",
    authDomain: "lishe360app.firebaseapp.com",
    databaseURL: "https://lishe360app.firebaseio.com",
    projectId: "lishe360app",
    storageBucket: "lishe360app.appspot.com",
    messagingSenderId: "922855494610"
  };
  firebase.initializeApp(config);



var messageRef = firebase.database().ref('Topics');
var photo;
var time =formatDate(new Date());

var fileButton = document.getElementById('fileButton'); 
  fileButton.addEventListener("change",function(e){
   var file= e.target.files[0];
  
   //create storage ref to the firebase storage
   var storageRef = firebase.storage().ref('topics').child(file.name);
   var task = storageRef.put(file);


   task.on("state_changed",function(snapshot){
      var percentage= (snapshot.bytesTransferred/snapshot.totalBytes) *100;
      if(percentage==100){
             storageRef.getDownloadURL().then(function (photourl) {
             // You will get the Url here.
              photo=photourl;
          });
      }
   });

});


document.getElementById('TopicForToday').addEventListener('submit',submitForm);

//document.getElementById('notyform').addEventListener('submit',sendNotification);

function submitForm(e){
	e.preventDefault();


	//get values
	var maintitle = getInputVal('maintitle');
  var descption = getInputVal('descption');
   
	//save message
	saveMessage(maintitle,descption,photo,time);
  document.getElementById("noty_title").value = maintitle;
  document.getElementById("noty_message").value = descption;
  document.getElementById("noty_image").value = "ujanja";
  document.notyform.submit();

    //shoe alert
    $("#success_sms").classList.remove("hide");


    //hide alert after 3 seconds
    setTimeout(function(){
        $("#success_sms").classList.add("hide");
    },3000);

	//clear form
	document.getElementById('TopicForToday').reset();
  reload_page();
}


// function to get form values

  function getInputVal(id){
  	return document.getElementById(id).value;
  }


  function addZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}


  function formatDate(date) {
  var monthNames = [
    "January", "February", "March",
    "April", "May", "June", "July",
    "August", "September", "October",
    "November", "December"
  ];

  var day = date.getDate();
  var monthIndex = date.getMonth();
  var year = date.getFullYear();
  var hours = addZero(date.getHours());
  var minutes = addZero(date.getMinutes());
  var seconds = addZero(date.getSeconds());

  return 'posted '+ day + ' ' + monthNames[monthIndex] + ' ' + year + ' at ' + hours + ':' + minutes + ':' + seconds;
}


  //save message to firebase

  function saveMessage(maintitle,descption,photo,time){
  	var newMessageRef = messageRef.push();
  	newMessageRef.set({
      maintitle:maintitle,
      descption:descption,
      photo:photo,
      time:time
  	});
  }

    function reload_page(){
        window.location.reload();
    }