<?php
// Firebase API Key
define('FIREBASE_API_KEY', 'AIzaSyBiVarlBEE1GmmwrAzaulpXw4ttcHehcRc');

?>
